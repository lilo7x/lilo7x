#!/bin/bash

mkdir -p backup

tar -czf backup books.txt
echo "Sauvegarde réussie"
