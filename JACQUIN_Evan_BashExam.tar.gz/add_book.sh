#!/bin/bash

#Informations sur le livre
echo "Titre du livre : "
read titre

echo "Auteur du livre : "
read auteur

echo "Année du publication : "
read annee

echo "Planète d'origine : "
read origine

echo "ISBN galactique : "
read isbn

#Ajout à books.txt
echo "$titre $auteur $annee $origine $isbn" >> books.txt

echo "Livre '$titre' ajouté" >> library/logs/setup.log
