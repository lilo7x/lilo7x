#!/bin/bash

#Recherche par titre 
echo "Quel livre recherchez-vous ? : "
read titre_recherche
if grep -i "$titre_recherche" books.txt; then
	echo "$titre_recherche existe."
else
	echo "$titre_recherche n'existe pas."
fi

#Recherche par Auteur
echo "Quel auteur recherchez-vous ? : "
read auteur_recherche
if grep -i "$auteur_recherche ? : " books.txt; then
	echo "$auteur_recherche existe."
else
	echo "$auteur_recherche n'existe pas."
fi

#Recherche par ISBN
echo "Chercher un ISBN : "
read isbn_recherche
if grep -i "$isbn_recherche" books.txt; then
	echo "$isbn_recherche existe."
else
	echo "$isbn_recherche n'existe pas."
fi
