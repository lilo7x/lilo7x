#!/bin/bash

#Vérification de l'existence de tous les répertoires et sous répertoires
if [ -d library ]; then
	echo "Le répertoire library existe."
else
	echo "Le répertoire library n'existe pas."
fi

if [ -d library/logs ]; then
	echo "Le sous-répertoire library/logs existe."
else
	echo "Le sous-répertoire library/logs n'existe pas."
fi

if [ -d library/scripts ]; then
	echo "Le sous-répertoire library/scripts existe"
else
	echo "Le sous-répertoire library/scripts n'existe pas."
fi

#Vérification de l'existance des fichiers
if [ -f library/books.txt ]; then
	echo "Le fichier books.txt existe"
else
	echo "Le fichier books.txt n'existe pas"
fi

if [ -f library/users.txt ]; then
	echo "Le fichier users.txt existe"
else
	echo "Le fichier users.txt n'existe pas"
fi

#Vérification des permissions
echo "$(ls -ld library/logs)"
echo "$(ls -ld library/scripts)"
echo "$(ls -l books.txt)"
echo "$(ls -l users.txt)"
