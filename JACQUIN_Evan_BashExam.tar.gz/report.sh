#!/bin/bash

errors=$(grep -i "erreur" -e "erreurs" -e "error" -e "errors" setup.log)
if [ -z "$errors" ]; then
	: #Aucune erreur trouvée
else
	echo "$errors"
fi
