#!/bin/bash

#Création du fichier log dans le sous répertoire library/logs
mkdir -p library/logs
> library/logs/setup.log
echo "Initialisation du fichier log" >> library/logs/setup.log

#Création des sous-répertoires
mkdir library/scripts
echo "Création des sous-répertoires library/logs et library/scripts" >> library/logs/setup.log

#Initialisation des fichiers books.txt et users.txt
touch library/books.txt | echo "#Base de données des livres" >> books.txt
chmod 744 books.txt
echo "Initialisation du fichier books.txt" >> library/logs/setup.log

touch library/users.txt | echo "#Base de données de utilisateurs" >> users.txt
chmod 744 users.txt
echo "Initialisation du fichier users.txt" >> library/logs/setup.log
