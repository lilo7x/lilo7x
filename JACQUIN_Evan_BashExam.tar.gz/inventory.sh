#!/bin/bash

#Lister les livres
echo "Liste des livres possédés : "
cat books.txt

#Statistiques
#Nombre de livres

nb_livres=$(wc -1 books.txt)
echo "$nb_livres disponibles."

